//Application Window Component Constructor
function ApplicationWindow() {
    
    var admob = require("ti.android.admob");
	
	var adWindow = require('/ui/handheld/android/AdWindow');
	
	var window = Titanium.UI.createWindow({
	    backgroundColor : '#607D8B',
	    exitOnClose : true
	});
	
	//TRADITIONAL ADVIEW
    var adView = admob.createView({
        top: 0,
        adSizeType: 'SMART', //RECTANGLE, FULLBANNER, LEADERBOARD, SMART, FLUID
        publisherId : "ca-app-pub-xxxxxxxxxxxxx~xxxxxxx", //USE YOUR PUBLISHER ID HERE
        testDeviceId : "G9CCEHKYF95FFR8152FX50D059DC8336", //USE YOUR DEVICE ID HERE
        adUnitId: 'ca-app-pub-xxxxxxxxxxxxx/xxxxxxx', //USE YOUR AD_UNIT ID HERE
    }); 
    window.add(adView);
    
    adView.addEventListener('ad_received', function(e) {
        Titanium.API.info("Ad received");
    });
    
    adView.addEventListener('ad_not_received', function(e) {
        Titanium.API.info("Ad failed");
    });
	
	var button = Titanium.UI.createButton({
	    title : 'Open new window'
	});
	window.add(button);
	
	button.addEventListener('click', function(){
	    new adWindow().open();
	});
	
	return window;
}

//make constructor function the public component interface
module.exports = ApplicationWindow;
