function AdWindow() {

    var admob = require("ti.android.admob");

    var win = Ti.UI.createWindow({
        layout : 'vertical',
        backgroundColor : '#ffffff',
        navBarHidden : true,
        exitOnClose : false
    });

    win.addEventListener('android:back', function() {
        Titanium.API.info('android:back');
        interstitialAd.destoyAdViewAndCancelRequest();
        win.close();
    });

    //INTERSTITIAL ADVIEW
    var interstitialAd = admob.createView({
        adSizeType: 'INTERSTITIALAD',
        publisherId : "ca-app-pub-xxxxxxxxxxxxx~xxxxxxx", //USE YOUR PUBLISHER ID HERE
        testDeviceId : "G9CCEHKYF95FFR8152FX50D059DC8336", //USE YOUR DEVICE ID HERE
        adUnitId: 'ca-app-pub-xxxxxxxxxxxxx/xxxxxxx', //USE YOUR AD_UNIT ID HERE
    });
    win.add(interstitialAd);

    interstitialAd.addEventListener('ad_received', function(e) {
        Titanium.API.warn("Interstital Ad Received");
    });

    interstitialAd.addEventListener('ad_not_received', function(e) {
        Titanium.API.error("Interstital Ad failed");
    });

    interstitialAd.addEventListener('ad_ready_to_be_shown', function(e) {
        Titanium.API.warn("Interstital Ad is READY!");
        interstitialAd.showAdNow();
    });

    interstitialAd.addEventListener('ad_not_ready_yet', function(e) {
        Titanium.API.warn("Interstital Ad is not ready yet!");
    });

    interstitialAd.addEventListener('ad_being_shown', function(e) {
        Titanium.API.warn("Interstital Ad being shown right now!");
    });

    interstitialAd.addEventListener('ad_closed', function(e) {
        Titanium.API.warn("Interstital ad close successfully. RIP!");
    });

    return win;
}

module.exports = AdWindow;
